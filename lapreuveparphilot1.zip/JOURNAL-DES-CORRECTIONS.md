# La preuve par Φ — journal des corrections

**Dépôt** : `asemantix/PHI` · branche `main`
**Archive livrée** : `lapreuveparphi-lot1.zip` — 53 fichiers à écraser tels quels.
**Un fichier à supprimer à la main** : `Pourquoi-╬ª.html` (voir § 3).

---

## 1. Ce qui était le plus urgent, et que tu n'avais pas identifié

Le sitemap n'était pas le problème principal. **Dix pages déclaraient encore
`phi-signature.fr` comme adresse canonique** — c'est-à-dire qu'elles disaient à
Google : « la vraie version de cette page est sur l'ancien domaine ». Une
redirection 301 côté Gandi ne suffit pas à contredire une balise canonique : tant
qu'elle pointe ailleurs, Google hésite à indexer la nouvelle adresse, et
l'autorité acquise ne se transfère pas.

Pages concernées : les 8 pages `professions/`, `Pourquoi-Φ.html`, `a-propos/A-Propos.html`.

Deux autres anomalies de même famille :

- `pour-la-salle-daudience.html` déclarait comme canonique… `echanges-confidentiels.html`. Elle demandait donc elle-même à ne pas être indexée.
- `Assistance.html` déclarait `assistance.html` en minuscule — GitHub Pages est sensible à la casse, la canonique pointait vers une 404.

Tout est corrigé : chaque page déclare désormais sa propre adresse sur
`lapreuveparphi.fr`, en canonique, en `hreflang` et en `og:url`.

---

## 2. Identité, coordonnées, société

| Avant | Après | Occurrences |
|---|---|---|
| `phi-signature.fr` | `lapreuveparphi.fr` | 10 pages |
| `phi-signature@proton.me` | `contact@lapreuveparphi.fr` | 8 pages |
| PHI SAS · filiale d'AION ASEMANTIX | **AION ASEMANTIX SASU** | 16 pages |
| PHI SAS (dans le corps du texte) | AION ASEMANTIX | 10 pages |
| PHI, entreprise individuelle (micro-entreprise), SIREN 950 561 167 | AION ASEMANTIX SASU | 4 pages |
| 33 rue du Frère Benoît, 69600 Oullins-Pierre-Bénite | 48 rue du Docteur Roux, 03100 Montluçon | 3 pages |
| Φ Signature | **Φ Preuve** | 3 pages |

L'adresse postale **ne s'affiche plus sur aucune page**. Elle subsiste à trois
endroits, volontairement :

1. `mentions-legales.html` — c'est sa place ;
2. les CGU, l'EULA et la politique de confidentialité — l'identification complète de l'éditeur y est légalement exigée ;
3. les données structurées JSON-LD, invisibles pour le visiteur, utiles à Google pour rattacher le site à l'entreprise.

> **À trancher.** Les CGU, l'EULA et la politique de confidentialité affichent
> encore le SIREN 950 561 167 — celui de l'entreprise individuelle. La SASU étant
> « en cours d'immatriculation », dis-moi si tu préfères garder ce SIREN
> jusqu'à l'immatriculation, ou le retirer dès maintenant.

---

## 3. Pages en double et pages fantômes

- **`Pourquoi-╬ª.html`** — c'était un doublon au nom cassé (encodage), mais, à la
  vérification, **c'était la version la plus à jour des deux** : elle portait déjà
  le bon domaine, le bon e-mail, la bonne adresse. J'ai donc versé son contenu
  dans `Pourquoi-Φ.html` (l'adresse que Google connaît et vers laquelle pointent
  tous les liens) et supprimé le fichier cassé. **À supprimer aussi de ton côté
  sur le dépôt.**
- **`a-propos/portefeuille-brevets.html`** et **`a-propos/valeur-et-fiabilite-de-la-signature.html`** — c'étaient déjà des pages de redirection, correctement faites. Conservées telles quelles, hors sitemap.
- **`urssaf.html`** (racine) — redirection, mais elle renvoyait vers `phi-signature.fr`. Réécrite proprement vers `professions/urssaf.html`.
- **`phi-parcours.html`** — conservée (elle sert la vidéo de `l-app-en-action.html`), passée en `noindex` et exclue du sitemap : ce n'est pas une page de contenu.

---

## 4. Liens morts

Neuf cibles mortes réparées sur l'ensemble du site :

| Lien mort | Redirigé vers |
|---|---|
| `assistance.html` (casse) | `Assistance.html` |
| `contact-commercial.html` | `contact.html` |
| `dpo.html` | `politique-confidentialite.html` |
| `faq-abonnement.html` | `faq.html` |
| `lapp-en-action.html` | `l-app-en-action.html` |
| `quatre-plans-phi.html` | `tarifications.html` |
| `a-propos/portefeuille-brevets.html` | `portefeuille-brevets.html` |
| `a-propos/valeur-et-fiabilite…` | `valeur-et-fiabilite…` |
| `/phi-public.phi` (clé publique non publiée) | bouton neutralisé « · bientôt », comme dans le pied de page de l'index |

> **Il reste deux liens morts que je n'ai pas voulu trancher seule**, sur
> `telecharger.html` : `/telechargements/la-preuve-par-phi.apk` et
> `/telechargements/verificateur-phi.html`. Les fichiers n'existent pas dans le
> dépôt. Ce sont les deux boutons principaux de la page de téléchargement — ils
> renvoient aujourd'hui une 404. Soit tu déposes les fichiers, soit je passe les
> boutons en « bientôt disponible ».

---

## 5. Pied de page

Un pied de page unique, **strictement identique sur les 46 pages de contenu**,
calqué sur celui de l'index (source de vérité), avec :

- les chemins ajustés automatiquement pour les sous-dossiers `professions/` et `a-propos/` ;
- **uniquement des liens vivants** — chaque cible a été vérifiée ;
- la mention société **AION ASEMANTIX SASU · contact@lapreuveparphi.fr**, sans adresse ;
- les baselines « La preuve par Φ — la primitive probatoire » / « Post-Quantique · Sans tiers de confiance » ;
- un lien « Accueil » ajouté en tête de la colonne *Accéder* (il manquait sur les pages intérieures) ;
- une feuille de style autonome injectée avec le pied de page, pour qu'il s'affiche à l'identique même sur les pages qui avaient leur propre mise en forme (`faq.html`, `telecharger.html`, `trois-volets.html` en avaient une différente).

---

## 6. Sitemap et robots

`sitemap.xml` reconstruit : **47 adresses**, toutes vérifiées comme existantes.

- Retirées : les pages de redirection, le fichier de vérification Google, `phi-parcours.html`, le doublon cassé.
- Priorités revues : l'accueil à 1.0 ; tarifs, téléchargement, professions, FAQ et « comment ça marche » à 0.9 ; les pages métier à 0.8 ; les pages légales à 0.3.
- `lastmod` au 2026-07-26 sur toutes les entrées.
- `robots.txt` complété d'un `Disallow` sur `phi-parcours.html`.

**À faire de ton côté, après le push :** dans la Search Console, propriété
`lapreuveparphi.fr` → *Sitemaps* → resoumettre `sitemap.xml`. Puis *Inspection
de l'URL* sur les 8 pages `professions/` et sur `pour-la-salle-daudience.html`,
avec « Demander une indexation » — ce sont celles dont la canonique était fausse.

---

## 7. Le produit : de la signature aux deux preuves

La grille LITE / AR / PROBATOR survivait dans les **CGU, article 05**, avec des
plans d'abonnement mensuels (Pack, Solo, Équipe, Business), des crédits à un
euro, et une offre « Fondateurs garantie à vie ». Article entièrement réécrit sur
le modèle réel, aligné mot pour mot sur `tarifications.html` :

- correspondre — gratuit et illimité ;
- vérifier une preuve — gratuit, sans compte ;
- **preuve légère — 1 jeton** ;
- **preuve renforcée — 3 jetons** ;
- jeton dégressif de 4,00 € à 2,00 € par paliers de 100 / 500 / 2 000 / 10 000 ;
- Φ Diffusion, SDK et licences d'organisation : par contrat, hors grille.

Corrigé dans la foulée, partout où le modèle par abonnement subsistait :

- CGU : durée de licence « limitée à la durée de l'abonnement » → sans limitation de durée ; article résiliation → cessation libre, jetons acquis ; plafond de responsabilité indexé sur les achats de jetons ;
- EULA : « obtenue via Google Play » → distribution directe depuis lapreuveparphi.fr ;
- politique de confidentialité : « vérification de l'abonnement » → vérification de la licence ;
- 4 pages métier : « Inclus dans l'abonnement » dans les tableaux comparatifs → « 1 jeton · 2 à 4 € » ;
- `professions/urssaf.html` : « un seul abonnement couvre tous les mandats » → « un seul stock de jetons » ;
- `professions/journalistes.html` : la page affirmait que l'app se télécharge « depuis l'App Store et le Play Store » — remplacé par la distribution souveraine, sans magasin ni compte ;
- `Assistance.html` : « inclus dans les abonnements Pro & Institution » → « inclus, sans surcoût » ;
- `Pourquoi-Φ.html` : crédits à un euro et « tarif Fondateurs gelé à vie » → jetons dégressifs, sans abonnement ;
- `index.html` : « Engagement (signature + accusé de réception) » → **« Preuve légère »** dans la FAQ et dans le JSON-LD.

---

## 8. Ce que je n'ai pas touché, et pourquoi

**Le mot « signature » est resté partout où il travaille pour le référencement** —
titres, méta-descriptions, mots-clés, URLs. La stratégie du doublement est
respectée : on entre par « signature électronique post-quantique sans tiers »,
on sort par la preuve autoportée. Les URLs `la-signature-probatoire.html` et
`valeur-et-fiabilite-de-la-signature.html` sont conservées telles quelles : les
renommer maintenant, trois jours après la migration de domaine, coûterait plus
que ça ne rapporterait.

---

## 9. Ce qui reste — et dans quel ordre

**a) `pour-la-salle-daudience.html` est un quasi-doublon.** Son texte est
identique à **91 %** à celui de `echanges-confidentiels.html` — même H1
(« Transmissions souveraines »), même argumentaire. Google traite ce genre de
paire comme du contenu dupliqué et n'en indexe qu'une. Deux issues : lui écrire
son propre contenu (l'angle salle d'audience : le juge, l'expert, le recalcul
contradictoire de G à l'audience), ou en faire une redirection. C'est le
correctif SEO le plus rentable qui reste.

**b) Propager la doctrine G aux pages intérieures.** L'index est juste — il porte
déjà la ligature, la métaphore longitude/latitude, et l'élargissement de l'objet
prouvé (photo, document, rapport, état des lieux, œuvre d'art, bijou, yacht,
jet). Les pages intérieures, elles, parlent encore surtout de signature de
document. Ce chantier est du rédactionnel, page par page, et mérite qu'on en
parle avant que je l'attaque.

**c) La typographie en dernier**, comme tu l'as dit — et je suis d'accord.
L'état des lieux : **43 pages sur 52 chargent encore IBM Plex Sans**, que la
charte de l'index a abandonné. L'index tourne à trois polices — Playfair Display
pour les titres, EB Garamond en italique pour le corps, IBM Plex Mono pour les
étiquettes. La bascule est mécanique et se fait en une passe, mais elle change
l'aspect de chaque page : à faire quand le contenu sera stabilisé, pas avant.
